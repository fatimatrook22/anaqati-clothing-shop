The Anaqati code of conduct is derived from the Ruby code of conduct. Any violations of conduct code may be reported to Anaqati.476@gmail.com

- Participants must ensure that their words and actions are free from personal attacks or negative remarks.
- When interpreting the words and actions of others, participants should always assume good intentions.
- Behavior that can be considered harassment will not be tolerated.
- Participants should be patient with opposing views.