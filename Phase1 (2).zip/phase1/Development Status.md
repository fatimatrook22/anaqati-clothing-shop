
# Development Status
ACTIVE DEVELOPMENT - middle of development beta  <br>
System has reached the end of its basic design and initial functionality. <br>
Project is still being put into action, though. 
However, entire project will be attempted to be implemented by developers and other contributors who are willing to join us.  <br>

Up until the completion of the project, each implemented function will be published to the repository. <br>

