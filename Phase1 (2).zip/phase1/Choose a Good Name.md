# The process for choosing a good name for project (Anaqati) is :
One of the most important things that we need when creating a free project is choose a good name for our project.
We must sure that the name of project be easy to remember and explain what the idea of the project is. 
Also it should be a unique name and not duplicate.
Therefore, we have taken many steps to choose the name of our project. 
we searched for on many sites that suggested a name for the project,
also use the chatgpt to help us to find a name that  is never used before 🔗
and we put the many names which are (Style - Anaqa -), then team members choose the best names,which are:<br>
1️-Anaqati <br>
