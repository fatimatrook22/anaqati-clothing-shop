
# Developer Documentation

## Installation & Setup
- Clone the repository:
```bash
git clone https://github.com/MaryamAref2003/anaqati-clothing-shop.git
cd anaqati-clothing-shop
```

## Environment
- PHP 7.4 or later recommended.
- No database setup currently required.

## Deployment
- Use any PHP-enabled web server (Apache/Nginx).

