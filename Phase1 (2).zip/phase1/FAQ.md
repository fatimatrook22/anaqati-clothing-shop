
# Frequently Asked Questions (FAQ)

## General Questions
**Q: What is Anaqati Clothing Shop?**
A: Anaqati is a free, open-source clothing shop application.

## User Questions
**Q: How can I report an issue?**
A: Issues can be reported via our [Issue Tracker on GitHub](https://github.com/MaryamAref2003/anaqati-clothing-shop.git).

## Contributor Questions
**Q: How can I start contributing?**
A: Check our [Contributor Guidelines](phase1-2/Developer Guidlines.md) to get started.
