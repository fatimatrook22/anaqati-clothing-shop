# 📣Announcement
it one of most important things that needs to be done in our project, and it will be at first page of our project , also it will contain some of keywords and short paragraph, we will not do announcement for the public, we will keep it for us as privet because it’s a course project 
