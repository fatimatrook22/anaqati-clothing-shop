# Hosting
Hosting refers to the platform where the project will be stored so that everyone can access it. We have chosen to host our project on GitHub because it is an open-source platform and free to use. This allows both users and developers to access the project and provide us with valuable feedback.<br>
our project: 
